public class Main{
    public static void thankPlayer(){
        System.out.println("Thanks for playing \"Snake\"!");
    }
    public static void main(String[] args){
        GameFrame game = new GameFrame();
        thankPlayer();
    }
}